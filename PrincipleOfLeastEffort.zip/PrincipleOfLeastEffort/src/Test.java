
public class Test {
	public static void main (String []args)
	{
		Canvas canvas = Canvas.getCanvas();
		Circle c = new Circle(20, 100, 100);
		c.makeVisible();
		
	}
}
