
public class TrainStation1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Canvas canvas = Canvas.getCanvas();
		Circle c = new Circle(20, 100, 100);
		c.makeVisible();
		
	}

}
