import java.util.ArrayList;
public class peopleOnStation {

	double xStairs = 50;
	double yStairs = 50;
	double xposition = 0;
	double yposition = 0;
	double length = 0;
	double velocity = 0.00;
	public void peopleOnStation() {
		// TODO Auto-generated method stub
			double length = 50.00;
			double effort = 100.00;
			double second = 1;
			for (int i = 0; i < 2500; i++)
			{
				double v = i/100;
				double newEffort = second*(2.23 + 1.26 * Math.abs(v*v)) + 2*Math.abs(length - v*second)*1.33;
				if (newEffort < effort)
				{
					effort = newEffort;
					velocity = v;
					
				}
			}
	   }
		
		public double getLength()
		{
			double length = Math.sqrt((xStairs-xposition)*(xStairs-xposition) + (yStairs-yposition)*(yStairs-yposition));
			return length;
		}
		
		public double getXPosition()
		{
			return xposition;
		}
		
		public double getYPosition()
		{
			return yposition;
		}
}
