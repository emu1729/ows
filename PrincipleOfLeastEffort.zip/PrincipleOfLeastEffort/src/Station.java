
public class Station {

}
